﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figuren
{
    class Afmeting
    {
        public Afmeting(int hoogte, int breedte);
        public int Hoogte { get; set; }
        public int Breedte { get; set; }
    }
}
