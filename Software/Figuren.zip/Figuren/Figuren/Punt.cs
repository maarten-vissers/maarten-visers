﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figuren
{
    class Punt
    {
        public Punt(int x, int y);
        public int X { get; set; }
        public int Y { get; set; }
    }
}
