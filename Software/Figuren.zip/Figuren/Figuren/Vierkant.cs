﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figuren
{
    class Vierkant : Figuur
    {
        public override double Oppervlakte
        {
            get { throw new NotImplementedException(); }
        }
    }
}
